PyTorch implementation of the main application experiments
(Tables 2-4, 6, 9-11 and Figures 1-6) to be added by the authors.
